export const ALIVE_ENDPOINT = "/alive";
export const JS_CREATE_ENDPOINT = "/create/individual/json";
export const CSV_CREATE_ENDPOINT = "/create/individual/csv";
export const UPLOAD_ENDPOINT = "/upload";

export const LOCAL_IP = "localhost";
export const SERVER_IP = "54.206.144.207";

export const FRONTEND_PORT = 3000;
export const BACKEND_PORT = 4000;
