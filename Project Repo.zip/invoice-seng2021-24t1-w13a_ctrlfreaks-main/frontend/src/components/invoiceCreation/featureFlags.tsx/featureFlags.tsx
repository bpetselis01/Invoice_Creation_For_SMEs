/**
 * Feature flags for the application
 */

/**
 * Feature flag for the JSON input
 */
export const JSON_INPUT_FEATURE_FLAG = true;

/**
 * Feature flag for the CSV input
 */
export const CSV_INPUT_FEATURE_FLAG = true;
