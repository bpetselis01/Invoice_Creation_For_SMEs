import { memo } from "react";

/**
 * This component is a placeholder for the manual input tab.
 * FIXME: Implement this component.
 */
export const ManualInput = memo(function ManualInput() {
  return <div>ManualInputTab</div>;
});
