export type RegistrationInfo = {
    email: string;
    username: string;
    phone: string;
    password: string;
    confirmPassword: string;
};